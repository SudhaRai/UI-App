import './styles/style.scss';
import bannerImg from "../src/assets/welcome-image.svg";
import weatherIcon from "../src/assets/icon-party-sunny.svg";

function App() {
  return (
    <div className="sirius-app">
      <section className="sirius-app-banner">
        <div className="sirius-app-banner_content">
          <p>Book now to get exciting travel deals. Upto 40% off on credit card payments<br /><span>Offers ends in 1d 10h 5m 10s</span></p>
        </div>
      </section>
      <header className="sirius-app-header">
        <div className="container">
          <nav>
            <ul>
              <li><a href="#">WEATHER</a></li>
              <li><a href="#">DESTINATIONS</a></li>
              <li><a href="#">GET A QUOTE</a></li>
            </ul>
          </nav>
        </div>
      </header>
      <section className="sirius-app-hero-banner">
        <div className="container">
          <div className="d-flex d-flex-align-items-center">
            <div className="d-flex-col txt-align-center">
              <img src={bannerImg} className="banner-img" alt="Banner Img" />
            </div>
            <div className="d-flex-col">
              <div className="sirius-app-hero-banner-content">
                <h1>Life is shot<br />
                  and the world is wide!</h1>
                <p>Stay at the comfort of your homes and book a trip to travel
                after the post pandemic era.</p>
                <div>
                  <button className="sirius-app-btn">PLAN A TRIP</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="sirius-app-weather-channel">
        <div className="container">
          <h2 className="title">THE WEATHER CHANNEL</h2>
          <div className="d-flex">
            <div className="d-flex-col">
              <div className="sirius-app-weather-list canberra">
                <h3>Canberra</h3>
                <img src={weatherIcon} />
                <h2>32</h2>
              </div>
            </div>
            <div className="d-flex-col">
              <div className="sirius-app-weather-list tokyo">
                <h3>Tokyo</h3>
                <img src={weatherIcon} />
                <h2>27</h2>
              </div>
            </div>
            <div className="d-flex-col">
              <div className="sirius-app-weather-list london">
                <h3>London</h3>
                <img src={weatherIcon} />
                <h2>22</h2>
              </div>
            </div>
            <div className="d-flex-col">
              <div className="sirius-app-weather-list dubai">
                <h3>Dubai</h3>
                <img src={weatherIcon} />
                <h2>38</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="sirius-app-featured-destinations">

      </section>
      <section className="sirius-app-plan-a-trip">
        <div className="sirius-app-plan-a-trip-content">
          <div>
            <h2>PLAN A TRIP</h2>
            <p>Make your vacation the most<br />
              memorable one</p>
          </div>
        </div>
      </section>
      <section className="sirius-app-get-a-quote">
        <div className="container">
          <h4 className="form-title">Travelling as a group? Get a Quote</h4>
          <form>
            <div className="form-grp">
              <label for="name">Your Name</label>
              <input type="text" required id="name" />
            </div>
            <div className="form-grp">
              <label for="contactno">Contact No</label>
              <input type="number" required maxLength="10" id="contactno" />
            </div>
            <div className="form-grp">
              <label for="email">Email</label>
              <input type="email" required id="email" />
            </div>
            <div className="form-submit">
              <input type="submit" className="sirius-app-btn" value="Submit" />
            </div>
          </form>
        </div>
      </section>
      <footer>
        <div className="container">
          <div className="d-flex">
            <div className="d-flex-col">
              <div className="sirius-app-footer-list">
                <h4>Tripzone</h4>
                <ul>
                  <li><a href="#">About</a></li>
                  <li><a href="#">Awards</a></li>
                  <li><a href="#">Contact Us</a></li>
                  <li><a href="#">Feedback</a></li>
                </ul>
              </div>
            </div>
            <div className="d-flex-col">
              <div className="sirius-app-footer-list">
                <h4>Main Offices</h4>
                <ul>
                  <li><a href="#">The United States</a></li>
                  <li><a href="#">India</a></li>
                  <li><a href="#">Brazil</a></li>
                  <li><a href="#">Canada</a></li>
                </ul>
              </div>
            </div>
            <div className="d-flex-col">
              <div className="sirius-app-footer-list">
                <h4>Sub Offices</h4>
                <ul>
                  <li><a href="#">Australia</a></li>
                  <li><a href="#">England</a></li>
                  <li><a href="#">France</a></li>
                  <li><a href="#">Germany</a></li>
                </ul>
              </div>
            </div>
            <div className="d-flex-col">
              <div className="sirius-app-footer-list">
                <h4>Disclaimer</h4>
                <p>This layout is created as a pa  of Sirius UI Recruitments.
  All the above content has no direct relation with Sirius
  business.</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
